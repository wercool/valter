import httplib
import urllib
import smtplib
from email.MIMEText import MIMEText

def printText(txt):
    lines = txt.split('\n')
    for line in lines:
        print line.strip()


#httpServ = httplib.HTTPConnection("checkip.dyndns.com", 80)
httpServ = httplib.HTTPConnection("whatismyip.org", 80)
httpServ.connect()

httpServ.request('GET', '/')

response = httpServ.getresponse()

httpServ.close()

if response.status == httplib.OK:
    resp = response.read(200)
#    end = resp.find("</body>")
#    start = resp.find("Address: ")
    
#    msg = MIMEText(resp[start:end].strip())
    msg = MIMEText(resp)
    msg["Subject"] = "GB-08 Current IP"
    print msg.as_string()
    mail_server = smtplib.SMTP("smtp.gmail.com:587")
    mail_server.ehlo()
    mail_server.starttls()
    mail_server.ehlo()
    mail_server.login("amaistrenko", "dbrnjhbz1989")
    mail_server.sendmail("amaistrenko@gmail.com", "amaistrenko@gmail.com", msg.as_string())
    mail_server.close()
