import socket
import serial
from time import sleep
import threading

MAXLINE = 100

ser = serial.Serial('/dev/ttyACM0', 115200, timeout=0)

def linesplit(sock, maxline=0):
    buf = sock.recv(16)
    done = False
    while not done:
        # mid line check        
        if maxline and len(buf) > maxline:
            yield buf, True

        if "\n" in buf:
            (line, buf) = buf.split("\n", 1)
            err = maxline and len(line) > maxline
            yield line+"\n", err
        else:
            more = sock.recv(16)
            if not more:
                done = True
            else:
                buf = buf+more
    if buf:
        err = maxline and len(buf) > maxline
        yield buf, err

def threaded_ping():
    while True:
        ser.write("PING")
#        ser.close()
        print "PING"
        sleep(0.5)

ping = threading.Thread(target=threaded_ping, args = ())
ping.daemon = True
ping.start()

HOST = ''                
PORT = 9001
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((HOST, PORT))
s.listen(1)
while True:
    print "started..."
    conn, addr = s.accept()
    print 'Connected by', addr
    for line, err in linesplit(conn, MAXLINE):
        if err:
            print "Error: Line greater than allowed length %d (got %d)"  % (MAXLINE, len(line))
            break
        else:
            cmd = line.strip()
            print "Received CMD:", cmd
            ser.write(cmd)

            if (cmd.find("RADARROTATIONSET") > -1):
                cmd = "GETDISTANCE"
                ser.write(cmd)

            if cmd == 'GETBATTERYVOLTAGE':
                result = ser.readline().strip()
                conn.send(result + '\n')
                print result
            if cmd == 'GETLEFTWHEELENCODER':
                result = ser.readline().strip()
                conn.send(result + '\n')
                print result
            if cmd == 'GETRIGHTWHEELENCODER':
                result = ser.readline().strip()
                conn.send(result + '\n')
                print result
            if (cmd == 'GETDISTANCE'):
                result = ser.readline().strip()
                conn.send(result + '\n')
                print result
            if (cmd == 'GETDISTANCESCAN'):
               sleep(3)
               result = ser.readline().strip()
               if (result.find("SCAN:") > -1):
                   print result
                   conn.send(result + '\n')
conn.close()
