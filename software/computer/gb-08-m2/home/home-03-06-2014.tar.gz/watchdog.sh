#!/bin/bash

while [ 1 ]; do
   ping -c 1 192.168.0.1

    if [ $? -eq 0 ]
    then
       echo "wlan0 active"
    else
       echo "wlan0 failed"
       echo "stop and reboot now!"
       killall python2.7
       reboot
    fi

    sleep 5
done
