/* empty stub to allow objectlist.awk.in to be created */
