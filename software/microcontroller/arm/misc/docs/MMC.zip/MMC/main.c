// This program shows how to work whit SPI interface and
// connected to it multimedia card
// Programs read/write buffer to MMC card

#include "AT91SAM7S64.h"
#include "system.h"
#include "mmc.h"
#include "string.h"

//MAIN POINTER
AT91PS_PIO    m_pPio   = AT91C_BASE_PIOA;

//it's a simple delay
void Delay (unsigned long a) { while (--a!=0); }

// external buffer which is use to read/write in MMC card
extern char mmc_buffer[512];

int main()
{
  /**** System init ****/
  InitFrec();
  Init_CP_WP();

  //chek for CP and WP
  //CP - card present
  while(((m_pPio->PIO_PDSR) & BIT15)) { /*put your card present event here*/  }
  //WP - write protect
  while(((m_pPio->PIO_PDSR) & BIT16)) { /*put your write protect event here*/ }



  /**** MMC CARD ****/
  if (initMMC() == MMC_SUCCESS)	// card found
  {
    //card_state |= 1;
    memset(&mmc_buffer,0,512);
    mmcReadRegister (10, 16);
    mmc_buffer[7]=0;

    // Fill first Block (0) with 'A'
    memset(&mmc_buffer,'0',512);    //set breakpoint and trace mmc_buffer contents
    mmcWriteBlock(0);
    // Fill second Block (1)-AbsAddr 512 with 'B'
    memset(&mmc_buffer,'1',512);
    mmcWriteBlock(512);

    // Read first Block back to buffer
    memset(&mmc_buffer,0x00,512);
    mmcReadBlock(0,512);

    // Read first Block back to buffer
    memset(&mmc_buffer,0x00,512);
    mmcReadBlock(512,512);
  }

  while(1)
  {

  }
}

