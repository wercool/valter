// This program is designed for ADUC_P7020 board
// It shows how to work with uart interface

#include <ioaduc7020.h>
#include "system.h"
#include "uart.h"


//variable
unsigned char ch = 0x0;

int main()
{
  // Init frequency
  InitFreq();
  // Init UART
  InitUart();

  // loop forever
  while(1) {

    // echo for uart
    ch = ReadChar();
    WriteChar(ch);
    WriteChar('*');

  }

}
