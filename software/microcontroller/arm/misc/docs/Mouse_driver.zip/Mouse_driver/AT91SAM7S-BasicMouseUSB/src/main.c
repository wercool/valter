//*--------------------------------------------------------------------------------------
//*      ATMEL Microcontroller Software Support  -  ROUSSET  -
//*--------------------------------------------------------------------------------------
//* The software is delivered "AS IS" without warranty or condition of any
//* kind, either express, implied or statutory. This includes without
//* limitation any warranty or condition with respect to merchantability or
//* fitness for any particular purpose, or against the infringements of
//* intellectual property rights of others.
//*--------------------------------------------------------------------------------------
//* File Name           : USB HID example
//* Object              :
//* Translator          :
//* 1.0 05/Oct/04 ODi	: CReation
//* 1.1 04/Nov/04 JPP	: Add led1 On at power supply
//*--------------------------------------------------------------------------------------

#include "board.h"
#include "dbgu.h"
#include "hid_enumerate.h"

#define BUTTON_SAMPLING 1700 // Sampling frequency of buttons

#define BL_OFF(pio) ((pio) & SW1)
#define BR_OFF(pio) ((pio) & SW2)
#define BU_OFF(pio) ((pio) & SW3)
#define BD_OFF(pio) ((pio) & SW4)

#define BL_ON(pio) (!BL_OFF(pio))
#define BR_ON(pio) (!BR_OFF(pio))
#define BU_ON(pio) (!BU_OFF(pio))
#define BD_ON(pio) (!BD_OFF(pio))
#define CLICKL_ON 1
#define CLICKR_ON 2

struct _AT91S_HID 	HID;

//*----------------------------------------------------------------------------
//* \fn    AT91F_USB_Open
//* \brief This function Open the USB device
//*----------------------------------------------------------------------------
void AT91F_USB_Open(void)
{
    // Set the PLL USB Divider
    AT91C_BASE_CKGR->CKGR_PLLR |= AT91C_CKGR_USBDIV_1 ;

    // Specific Chip USB Initialisation
    // Enables the 48MHz USB clock UDPCK and System Peripheral USB Clock
    AT91C_BASE_PMC->PMC_SCER = AT91C_PMC_UDP;
    AT91C_BASE_PMC->PMC_PCER = (1 << AT91C_ID_UDP);

    // Enable UDP PullUp (USB_DP_PUP) : enable & Clear of the corresponding PIO
    // Set in PIO mode and Configure in Output
    AT91F_PIO_CfgOutput(AT91C_BASE_PIOA,AT91C_PIO_PA25);
    // Clear for set the Pul up resistor
    AT91F_PIO_SetOutput(AT91C_BASE_PIOA,AT91C_PIO_PA25);
    //AT91F_PIO_ClearOutput(AT91C_BASE_PIOA,AT91C_PIO_PA25);

    //AT91F_PIO_CfgInput(AT91C_BASE_PIOA,AT91C_PIO_PA24);
    //AT91F_PIO_CfgPullup(AT91C_BASE_PIOA,~AT91C_PIO_PA24);
    //while(!(AT91F_PIO_GetInput(AT91C_BASE_PIOA)&AT91C_PIO_PA24));

    // CDC Open by structure initialization
    AT91F_HID_Open(&HID, AT91C_BASE_UDP);
}

//*--------------------------------------------------------------------------------------
//* Function Name       : main
//* Object              :
//*--------------------------------------------------------------------------------------
int main ( void )
{
	char prevButton = 0, button = 0;
	int x = 0, y = 0;
	unsigned int pioStatus;

    //Init trace DBGU
    //AT91F_DBGU_Init();
    //AT91F_DBGU_Printk("\n\r-I- BasicUSB 1.1 (USB_DP_PUP) \n\r0) Set Pull-UP 1) Clear Pull UP\n\r");


    // Init USB device
    AT91F_USB_Open();

    // Configure the RTT:
    *AT91C_RTTC_RTMR = BUTTON_SAMPLING;

    // Set in PIO mode and Configure in Input
    AT91F_PIOA_CfgPMC();
    AT91F_PIO_CfgInput(AT91C_BASE_PIOA, (SW1|SW2));


    // Wait for the end of enumeration
    while (!HID.IsConfigured(&HID));

    // Start waiting some cmd
    while (1) {
		// Check enumeration
		if (HID.IsConfigured(&HID)) {
			// Wait for several ms
			while ( !((*AT91C_RTTC_RTSR) & AT91C_SYSC_RTTINC) );
			// Check PIO changes
			pioStatus = *AT91C_PIOA_PDSR;
			// Click on Button Left
			if (BL_ON(pioStatus) && BR_OFF(pioStatus)) {
				x = (x > 0) ? -1 : ((-127 < x) ? --x : x);
				AT91F_PIO_ClearOutput(AT91C_BASE_PIOA, LED2);
				AT91F_PIO_SetOutput(AT91C_BASE_PIOA, LED1);
			}
			// Click on Button Right
			else if (BL_OFF(pioStatus) && BR_ON(pioStatus)) {
				x = (x < 0) ? 0 : ((x < 127) ? ++x : x);
				AT91F_PIO_ClearOutput(AT91C_BASE_PIOA, LED1);
				AT91F_PIO_SetOutput(AT91C_BASE_PIOA, LED2);
			}
			// Click on Both
			else if (BL_ON(pioStatus) && BR_ON(pioStatus)) {
				button |= CLICKL_ON;
				x = 0;
				AT91F_PIO_SetOutput(AT91C_BASE_PIOA, LED1|LED2);
			}
			// Release right/left button
			else {
				button &= ~(CLICKL_ON);
				x = 0;
				AT91F_PIO_ClearOutput(AT91C_BASE_PIOA, LED1|LED2);
			}
			if (BU_ON(pioStatus) && BD_OFF(pioStatus)) {
				y = (y > 0) ? -1 : ((-127 < y) ? --y : y);
				AT91F_PIO_ClearOutput(AT91C_BASE_PIOA, LED4);
				AT91F_PIO_SetOutput(AT91C_BASE_PIOA, LED3);
			}
			else if (BU_OFF(pioStatus) && BD_ON(pioStatus)) {
				y = (y < 0) ? 0 : ((y < 127) ? ++y : y);
				AT91F_PIO_ClearOutput(AT91C_BASE_PIOA, LED3);
				AT91F_PIO_SetOutput(AT91C_BASE_PIOA, LED4);
			}
			else if (BU_ON(pioStatus) && BD_ON(pioStatus)) {
				button |= CLICKR_ON;
				y = 0;
				AT91F_PIO_SetOutput(AT91C_BASE_PIOA, LED3|LED4);
			}
			else {
				button &= ~(CLICKR_ON);
				y = 0;
				AT91F_PIO_ClearOutput(AT91C_BASE_PIOA, LED3|LED4);
			}
			// Send Coordinates	
			if ((prevButton != button) || x || y) {
				prevButton = button;
				HID.SendReport(&HID, button, x, y);
			}	

        }
   }
}


