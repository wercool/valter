KAdefine("javascript/cs-intro-package/cs-intro.js", function(require, module, exports) {
var $=require("jquery")
var guiders=require("../../third_party/javascript-khansrc/Guiders-JS/guiders.js")
var i18n=require("../shared-package/i18n.js")
var Cookies=require("../shared-package/cookies.js")
var KA=require("../shared-package/ka.js")
var CsIntro={showLoginTeaser:function(){if($(".phantom-notification-bar").length){return}var e=Cookies.readCookie("csPhantomBait")
if(!e||e==="shown promo"){return}if(KA.isIPad||/\/hour-of-/.test(window.location.pathname)){return}var o=i18n._("Congratulations on your first program! Sign up "+"and experiment more!")
guiders.createGuider({buttons:[{action:guiders.ButtonAction.CLOSE,text:i18n._("No, I don't want to be awesome."),classString:"simple-button"},{action:guiders.ButtonAction.CLOSE,text:i18n._("Yes, please! Sign me up!"),onclick:function(){window.location.href="/signup?continue="+encodeURIComponent(window.location.pathname)},classString:"simple-button green"}],title:i18n._("Become a computer science superstar"),description:o,overlay:true}).show()
Cookies.createCookie("csPhantomBait","shown promo")}}
module.exports=CsIntro
});
