KAdefine("javascript/shared-components-package/modal.jsx", function(require, module, exports) {
var React=require("react")
var classNames=require("classnames")
var _require=require("aphrodite")
var StyleSheet=_require.StyleSheet
var css=_require.css
var constants=require("../shared-styles-package/constants.js")
var Modal=React.createClass({displayName:"Modal",propTypes:{backdrop:React.PropTypes.oneOf([true,false,"static"]),children:React.PropTypes.node.isRequired,className:React.PropTypes.string,extraWide:React.PropTypes.bool,footer:React.PropTypes.node,forceTop:React.PropTypes.bool,fullScreen:React.PropTypes.bool,inline:React.PropTypes.bool,keyboard:React.PropTypes.bool,onClose:React.PropTypes.func,preventScrollOnShow:React.PropTypes.bool,showCloseButton:React.PropTypes.bool,title:React.PropTypes.string,wide:React.PropTypes.bool},getDefaultProps:function(){return{backdrop:true,className:"",extraWide:false,forceTop:false,fullScreen:false,inline:false,keyboard:true,onClose:function(){},preventScrollOnShow:false,showCloseButton:false,title:"",wide:false}},getInitialState:function(){return{visible:true,activeElement:null}},componentWillMount:function(){this.setState({activeElement:document.activeElement})},componentDidMount:function(){if(this.props.keyboard){window.addEventListener("keydown",this.handleEsc,true)}},componentWillUnmount:function(){if(this.props.keyboard){window.removeEventListener("keydown",this.handleEsc,true)}},handleClose:function(){this.setState({visible:false})
this.props.onClose()
if(this.state.activeElement){this.state.activeElement.focus()}},handleEsc:function(e){if(e.keyCode===27){this.handleClose()}},render:function(){var e=this
if(!this.state.visible){return React.createElement("div",null)}var t=this.props.showCloseButton&&React.createElement("a",{className:css(styles.close),href:"javascript: void 0",onClick:this.handleClose},"×")
var o=this.props.children
if(this.props.title||this.props.footer){o=React.createElement("div",null,this.props.title&&React.createElement("div",{className:css(styles.header)},React.createElement("h2",{className:css(styles.heading)},this.props.title)),React.createElement("div",{className:css(styles.body)},this.props.children),this.props.footer&&React.createElement("div",{className:css(styles.footer)},this.props.footer))}return React.createElement("div",{className:css(this.props.inline&&styles.inlineWrap)},React.createElement("div",{className:classNames(css(styles.modal,this.props.forceTop&&styles.forceTop,this.props.wide&&styles.wide,this.props.extraWide&&styles.extraWide,this.props.fullScreen&&styles.fullScreen,this.props.inline&&styles.inlineModal),this.props.className),ref:function(t){if(t&&e.props.preventScrollOnShow){t.style.top=""+window.scrollY+"px"}}},t,o),this.props.backdrop&&React.createElement("div",{className:css(styles.backdrop,this.props.inline&&styles.inlineBackdrop,this.props.forceTop&&styles.forceTopBackdrop),onClick:this.handleClose}))}})
var width=560
var wideWidth=700
var extraWideWidth=1e3
var margin=30
var styles=StyleSheet.create({inlineWrap:{overflow:"auto",position:"relative"},modal:{backgroundColor:constants.white,backgroundClip:"padding-box",border:"1px solid rgba(0, 0, 0, 0.3)",borderRadius:constants.borderRadiusLarge,boxShadow:"0 3px 7px rgba(0, 0, 0, 0.3)",left:"50%",margin:"0 0 0 "+-width/2+"px",outline:"none",padding:constants.modalDialogPadding,position:"fixed",top:"10%",width:width,zIndex:constants.zindexModal},inlineModal:{margin:"10px 0 10px "+-width/2+"px",position:"relative"},forceTop:{zIndex:20001},wide:{margin:"0 0 0 "+-wideWidth/2+"px",width:wideWidth},extraWide:{margin:"0 0 0 "+-extraWideWidth/2+"px",width:extraWideWidth},fullScreen:{bottom:margin,left:margin,minHeight:500-2*margin,minWidth:constants.minContainerWidth-2*margin,position:"fixed",right:margin,top:margin,width:"auto"},backdrop:{backgroundColor:constants.kaBlue,bottom:0,left:0,opacity:.85,position:"fixed",right:0,top:0,zIndex:constants.zindexModalBackdrop},forceTopBackdrop:{zIndex:2e4},inlineBackdrop:{position:"absolute"},close:{color:constants.black,cursor:"pointer","float":"right",fontSize:constants.baseLineHeight,fontWeight:"bold",lineHeight:constants.baseLineHeight,opacity:.2,textShadow:"0 1px 0 "+constants.white,textDecoration:"none",":hover":{opacity:.4},":focus":{opacity:.4}},header:{borderBottom:"1px solid "+constants.grayLighter,padding:"0 0 "+constants.modalSectionPadding+" 0"},heading:{color:constants.grayDark,fontFamily:constants.headerFontFamily,marginBottom:0,paddingTop:constants.modalSectionPadding},body:{margin:0,maxHeight:"none",padding:""+constants.contentPadding+" 0 "+(""+constants.modalSectionPadding+" 0"),position:"relative"},footer:{backgroundColor:constants.white,borderTop:"1px solid "+constants.grayLighter,marginBottom:0,padding:""+constants.modalDialogPadding+" 0 0 0",overflow:"hidden",textAlign:"right"}})
module.exports=Modal
});
KAdefine("javascript/shared-components-package/button.jsx", function(require, module, exports) {
var classNames=require("classnames")
var React=require("react")
var i18n=require("../shared-package/i18n.js")
var KUIButton=React.createClass({displayName:"KUIButton",propTypes:{borderless:React.PropTypes.bool,disabled:React.PropTypes.bool,domainSlug:React.PropTypes.string,href:React.PropTypes.string,label:React.PropTypes.node,onClick:React.PropTypes.func,progress:React.PropTypes.oneOf(["complete","started","unstarted"]),shadow:React.PropTypes.bool,size:React.PropTypes.oneOf(["normal","small"]),transparent:React.PropTypes.bool,type:React.PropTypes.oneOf(["button","submit"]).isRequired,typeStyle:React.PropTypes.oneOf(["button","submit"]),use:React.PropTypes.oneOf(["primary","secondary","gray","white","blue"]),width:React.PropTypes.string},getDefaultProps:function(){return{use:"primary",width:"auto",progress:"complete",borderless:false,shadow:false,transparent:false,disabled:false,size:"normal"}},getLabel:function(){return this.props.label!=null?this.props.label:this.props.type==="submit"?i18n._("Submit"):""},handleLinkClick:function(e){if(this.props.disabled){e.preventDefault()
return}var t=undefined
if(this.props.onClick){t=this.props.onClick(e)}if(this.props.type==="submit"&&t!==false&&!e.defaultPrevented){var s=e.target
var r=s.parentNode
var o=s.ownerDocument.createElement("button")
o.type="submit"
o.style.display="none"
r.insertBefore(o,s)
o.click()
r.removeChild(o)}if(!this.props.href){e.preventDefault()}return t},render:function(){var e=this.props.domainSlug
var t=this.props.progress
var s=this.props.typeStyle||this.props.type
var r=classNames({"kui-button":true,"kui-button-submit":s==="submit","kui-button-plain":s==="button","kui-button-borderless":this.props.borderless,"kui-button-shadow":this.props.shadow,"kui-button-disabled":this.props.disabled,"kui-button-small":this.props.size==="small","kui-button-primary":!e&&this.props.use==="primary","kui-button-secondary":!e&&this.props.use==="secondary","kui-button-gray":!e&&this.props.use==="gray","kui-button-white":this.props.use==="white","kui-button-blue":this.props.use==="blue","kui-button-domain":!!e,"kui-button-complete":e&&t==="complete","kui-button-transparent":this.props.transparent})+(e?" kui-button-domain-"+e:"")
return React.createElement("a",{role:"button","aria-disabled":this.props.disabled?"true":"false",onClick:this.handleLinkClick,href:this.props.href||"javascript:void(0)",className:r,style:{width:this.props.width}},this.getLabel())}})
module.exports=KUIButton
});
