KAdefine("javascript/promos-package/promos.js", function(require, module, exports) {
var _require=require("../shared-package/khan-fetch.js")
var khanFetch=_require.khanFetch
var Promos={}
Promos.cache_={}
Promos.hasUserSeen=function(e,o,r){if(e in Promos.cache_){o.call(r,Promos.cache_[e])
return}khanFetch("/api/internal/user/promo/"+encodeURIComponent(e)).then(function(e){return e.json()}).then(function(n){Promos.cache_[e]=n
o.call(r,n)},function(){o.call(r,true)})}
Promos.markAsSeen=function(e){Promos.cache_[e]=true
return khanFetch("/api/internal/user/promo/"+encodeURIComponent(e),{method:"POST"})}
module.exports=Promos
});
